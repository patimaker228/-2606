﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace SlotMachineWPF
{
    public partial class MainWindow : Window
    {
        private readonly List<string> theoryQuestions = new List<string>
        {
            "Что такое класс?",
            "Что такое объект класса?",
            "Что понимается под инкапсуляцией?",
            "Что такое наследование?",
            "В чём суть полиморфизма?",
            "Что такое абстракция в контексте ООП?",
            "Какова роль интерфейса?",
            "Чем отличается интерфейс от абстрактного класса?",
            "Что такое конструктор и деструктор?",
            "Для чего нужны свойства (properties)?",
            "Что такое метод – и чем он отличается от функции?",
            "Что такое перегрузка методов (overloading)?",
            "Что такое переопределение методов (overriding)?",
            "Что такое виртуальный метод (virtual) и ключевое слово sealed?",
            "Какие модификаторы доступа существуют и для чего они нужны (public, private, protected, internal)?",
            "Что такое статические (static) поля и методы?",
            "Что понимается под «атрибутами» (fields) класса?",
            "В чём разница между агрегированием и композицией?",
            "Что такое ассоциация и зависимость (dependency) между классами?",
            "Как соотносятся слабая и жёсткая связанность (coupling)?",
            "Что такое высокий уровень сцепления (cohesion) класса?",
            "Какие принципы SOLID вы знаете?",
            "Что такое паттерн «Фабрика» (Factory)?",
            "Автомат"
        };

        private readonly List<string> practiceTasks = new List<string>
        {
            "Реализовать с общим виртуальным методом, демонстрирующим полиморфизм.",
            "Создать (репозиторий) с CRUD-операциями (Create, Read, Update, Delete).",
            "Написать (Factory Method) для создания объектов заданных типов по строковому ключу.",
            "Разработать (Singleton) для управления общим ресурсом.",
            "Реализовать (Strategy Pattern): класс-контекст и несколько алгоритмов, меняемых во время выполнения.",
            "Создать (Chain of Responsibility) для последовательной обработки запросов.",
            "Смоделировать (Observer): издатель (publisher) и несколько подписчиков (subscribers).",
            "Написать (Command Pattern) с отменой (undo) и выполнением (execute).",
            "Реализовать (Decorator Pattern) для расширения поведения объектов без изменения класса.",
            "Создать (Adapter Pattern), позволяющий работать с несовместимыми интерфейсами.",
            "Разработать (Facade Pattern) для упрощённого доступа к набору подсистем.",
            "Реализовать (Builder Pattern) для поэтапного создания сложного объекта.",
            "Написать (Prototype Pattern) с клонированием объектов.",
            "Создать (Bridge Pattern), разделяющий абстракцию и реализацию.",
            "Реализовать (Interpreter Pattern) для простого доменного языка.",
            "Разработать (Composite Pattern) для древовидной структуры объектов.",
            "Написать (Flyweight Pattern) для оптимизации разделяемого состояния.",
            "Реализовать (Memento Pattern) для сохранения и восстановления состояния объекта.",
            "Создать с возможностью отката (rollback) изменений.",
            "Разработать (Object Pool) для повторного использования экземпляров.",
            "Написать с ограничением размера и стратегией вытеснения (LRU).",
            "Реализовать (Event Aggregator) для рассылки сообщений между компонентами.",
            "Создать через рефлексию (динамическая загрузка классов из сборок).",
            "Реализовать объектов в JSON/XML и обратно.",
            "Разработать через интерфейс, позволяющий менять провайдер (консоль, файл, БД).",
            "Автомат"
        };

        private readonly List<string> subjectAreas = new List<string>
        {
            "Система управления библиотекой",
            "Интернет-магазин",
            "Учёт студентов и курсов",
            "Бронирование авиабилетов",
            "Управление автопарком",
            "Складской учёт",
            "Управление персоналом (HR)",
            "Социальная сеть",
            "Чат-бот для поддержки",
            "Медицинская карта пациента",
            "«Умный дом»",
            "Геолокационные сервисы",
            "Мультимедийный плеер",
            "Калькулятор налогов",
            "Трекер задач и проектов",
            "CRM-система для продаж",
            "Платформа онлайн-обучения",
            "Система мониторинга погоды",
            "Финансовый портфель пользователя",
            "2D-игровой движок",
            "Расписание кинотеатра",
            "Трекер привычек",
            "Система бронирования столиков в ресторане",
            "API для конвертации валют",
            "Сервис онлайн-голосования",
            "Автомат"
        };

        private Random random = new Random();
        private bool isSpinning = false;

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void SpinButton_Click(object sender, RoutedEventArgs e)
        {
            if (isSpinning) return;
            isSpinning = true;

            await SpinSlot(TheoryText, theoryQuestions);
            await SpinSlot(PracticeText, practiceTasks);
            await SpinSlot(DomainText, subjectAreas);

            CheckForAuto();
            isSpinning = false;
        }

        private async void AutoButton_Click(object sender, RoutedEventArgs e)
        {
            if (isSpinning) return;
            isSpinning = true;

            bool autoAchieved = false;
            while (!autoAchieved)
            {
                await SpinSlot(TheoryText, theoryQuestions);
                await SpinSlot(PracticeText, practiceTasks);
                await SpinSlot(DomainText, subjectAreas);

                autoAchieved = CheckForAuto();

                if (!autoAchieved)
                {
                    await Task.Delay(1000);
                }
            }

            isSpinning = false;
        }

        private async Task SpinSlot(TextBlock slot, List<string> items)
        {
            int spins = random.Next(15, 25);
            double delay = 50;

            for (int i = 0; i < spins; i++)
            {
                int index = random.Next(items.Count);
                slot.Text = items[index];

                if (i > spins / 2)
                {
                    delay += i * 2;
                }

                await Task.Delay((int)delay);
            }
        }

        private bool CheckForAuto()
        {
            bool theoryAuto = TheoryText.Text == "Автомат";
            bool practiceAuto = PracticeText.Text == "Автомат";
            bool domainAuto = DomainText.Text == "Автомат";

            if (theoryAuto && practiceAuto && domainAuto)
            {
                MessageBox.Show("Поздравляем! Вы получили автомат!", "Автомат",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return true;
            }
            else if (theoryAuto || practiceAuto || domainAuto)
            {
                return false;
            }

            return false;
        }
    }
}